/* X-MatchVW revision                       */
/* Revision 5.0 by Jose Nunez January 2001   */
/* characteristics :                         */ 
/* variable width dictionary                 */



/* This code is supplied exactly "as is" without any implications about			*/
/* anything whatsoever! It must not be used for publication of results using	*/
/* the X-Match algorithm without due acknowledgement and reference, and it must	*/
/* not be redistributed under ANY circumstances. Your cooperation is			*/
/* appreciated in these matters.												*/

/* The table length is variable and begins with no entries, thus the first		*/
/* tuple in each data stream is sent literally without any prefix code.			*/
/* A table miss causes the table to be expanded by one entry, whereas a table	*/
/* hit requires no table expansion. The literal (miss) position is always the	*/
/* last location in the table. Phased binary coding is used to represent table	*/
/* positions, with the literal position always coded in 1 bit (a '1').			*/

/* When the block size is between 4 and 7 the compression ratio = 1.0, it is    */
/* because of the dictionary is inicializated each time a page is ended and the */
/* page size is a tuple, so, each time a tuple is read the tuple is sent litera */
/* lly.                                                                         */

/* The coding used is a phased binary code which is defined as follows -		*/
/* The literal position is always the last location in the table, thus we must	*/
/* be able to code positions from the range 0 <= position < literal_position+1	*/
/* Let row = literal_position+1													*/
/* let k = ROUNDUP(log2 row)													*/
/* now if position < (2**k - row) then code position using k bits				*/
/* otherwise code (position + (2**k - row)) using k+1 bits						*/
/* Thus the codes are phased in as the length of the table grows.				*/
/* This method taken from "Text Compression", Bell, Cleary, Witten; pp 293		*/

/* Operates on blocked data.													*/
/* Works on all file sizes, i.e file size does not have to be an exact multiple	*/
/* of the block size. NOTE: This program INCLUDES blocks of zeroes.				*/

/* block_size = size in bytes of the input data block 							*/
/* input_file = name of file to be compressed									*/



/* set up control constants to be used */

/* 64 is maximun but allow smaller numbers*/

#define TOP_TABLE_ENTRIES 4097 /*RLI reserves only location for run_lengths*/ 
  /* the ABSOLUTE MAXIMUM SIZE in entries of the table */
#define MAX_BITS_REPIT 2.0
#define MAX_BITS_REPIT_ZERO 8.0
#define MAX_BITS_REPIT_TOP 0.0
 /*The number of bits used to code run lengths*/
#define NUM_FILES 1
#define PARSER 32
#define PARSER_2 10
#define LINE_1 13
#define LINE_2 10
#define BUFFER_SIZE 256
#define USE_MATCH_TYPE 1


/* set up libraries to be used */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include "user_strings.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

/* declare files to be used */

FILE *input_file;					/* input file */
FILE *output_file_comp;				/* output compressed file */

/*variables to calculate frequency*/

FILE *frequency;
float percent=0.0;
int miss_type_hits[6] ={0,0,0,0,0,0};
long match_type_hits[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
long double position_hits[1024] = {0};
int USE_PARSER = 1;
int CHANGE_PARSER = 0;

/* set up global variables to be used */

int aoa_adaptation; /*variable that holds the value to perform out of order adaptation*/

char name_of_input_file[1000];		/* name of input file to be compressed */
char name_of_output_file[1000];
string temp_string;					/* temporary string */

/*flag when repeating*/

int repeticion_active;
int repeticion;
int old_found_position;
word old_tuple;
int total_bytes_read=0;


int tuple_number;
int characters_read;				/* used to store the number of characters read in a block */

word tuple[TOP_TABLE_ENTRIES+1];	/* array of tuple characters */
string output_buffer;               /* buffer to place codes to output */
string match_type_code[16+1];			/* array of Huffman codes */
string miss_type_code[6+1];
int literal_position;				/* the position of the literal code (last in table) */

word buffer[BUFFER_SIZE+1];				/* buffer to store input blocks */
int buffer_entries;					/* number of full tuples in the buffer */

long double input_bits=0;					/* number of bits read in from the data file								*/
long double output_bits=0;					/* number of bits output to the compressed file for each individual block	*/
long double total_output_bits=0;			/* total number of bits output to the compressed file						*/
long double block_input_bits=0;
long double block_output_bits=0;
long double block_total_bits=0;
long double blocks_that_compress=0;
long double number_of_blocks=0;
long double number_of_zero_blocks=0;

int eof_flag=0;						/* indicates end of file condition */
int zero_block_flag=0;				/* indicates that a block full of zeroes has been read */

int match_type;
int old_match_type; /*out of order adaptation storage of the match types*/

int match_bits_to_output;
int literal_characters_required;

int row,k,twokminusrow;				/* variables for coding - see introduction */

long double hits=0;
long double misses=0;
int active_parser=1;
int switch_parser=1;


extern void string_cat(string *destination , string source);
extern void print_string();
extern void string_copy_ss(string *destination ,string source);
extern void string_copy_sw(string *destination ,word source);
extern void string_copy_ww(word *destination ,word source);
extern void string_copy_ws(word *destination ,string source);
extern void left_shift_string(string * source ,int n);

/* function to read in a block of data from the input file */

int get_next_block(int *tuples_read, int block_size)
{
	unsigned int ch;
	unsigned int ch2;
/*	unsigned int ch3;
	unsigned int ch4;*/
	int i;
	int bytes_read=0;
	int zero_block=1;
	int found_parser = 0;
	int record_bytes_read= 0;
	int spaces;
	buffer_entries=0;

	do
	{
			buffer[*tuples_read].length=0;
			bytes_read=0;
			found_parser = 0;
			spaces = 0;
			do
			{
					ch=(unsigned)getc(input_file);
					if(ch!=EOF)
					{
						/*if (ch == LINE_1 && active_parser == 0)
						{
							ch2=(unsigned)getc(input_file);
							if (ch2 == LINE_2)
							{
								active_parser = 1;
								printf("Parser active !!\n\n");
							}
							ungetc(ch2,input_file);
						}*/
					/*	if ( bytes_read == 0 && SWITCH_PARSER == 1)
						{
							ch2=(unsigned)getc(input_file);
							ch3=(unsigned)getc(input_file);
							ch4=(unsigned)getc(input_file);


							if (ch <= 127)

							if (ch <= 127  && ch2 <= 127 && ch3 <= 127 && ch4 <= 127) */

						/*	if ((ch >= 32 && ch <= 126) && (ch2 >= 32 && ch2 <= 126) && (ch3 >= 32 && ch3 <= 126) && (ch4 >= 32 && ch4 <= 126))*/
					/*		{
								active_parser = 1;
							}
							else
							{
								active_parser = 0;
							}
							ungetc(ch4,input_file);
							ungetc(ch3,input_file);
							ungetc(ch2,input_file);
							
							
						} */

						/*this simpler alternative works better in the moment a byte is non_ASCII switch off parsing for the rest of the block*/
						
						//if ((ch >= 128 ) && active_parser == 1 && SWITCH_PARSER == 1)
						//{
						//		active_parser = 0;
						//}

						/*this alternative searches the first 16 bytes for a ch > 128 if so parser is non active otherwise parser is activated*/

						if (( ch == 0 || ch >= 128) && active_parser == 0 && switch_parser == 1 && total_bytes_read <= 16)
						{
							active_parser = 0;
							switch_parser = 0;
						}
						if (total_bytes_read > 16 && switch_parser == 1)
						{
							active_parser = 1;
						}

						if ((zero_block==1) && (ch ==0))
							zero_block=0;
						buffer[*tuples_read].data[bytes_read]=ch;
						buffer[*tuples_read].length++;
						bytes_read++;
						total_bytes_read++;
						record_bytes_read++;
						if ( ch == PARSER && bytes_read == 1 && spaces == 0)
							spaces = 1;	
						if ( active_parser == 1 && ch == PARSER)
						{
							ch2=(unsigned)getc(input_file);
							if(spaces == 1 && ch2 == PARSER /* && buffer[*tuples_read].data[bytes_read-2] == PARSER)*/)
								found_parser = 0;
							else
							{
								found_parser = 1;
								for(i = bytes_read; i< 4; i++)
										buffer[*tuples_read].data[bytes_read]=32;
							}
							ungetc(ch2,input_file);
						}
					}
				}while ((bytes_read<4) && (ch!=EOF) && (found_parser == 0));
			if (bytes_read>0) /*The last tuple must be processed even if it is incomplete*/
				(*tuples_read)++;	

	}
	while ((total_bytes_read<block_size) && (ch!=EOF) && *tuples_read<BUFFER_SIZE);

	if ((ch=(unsigned)getc(input_file))==EOF)
	{
		eof_flag=1;
	
	}
	else
	{
		ungetc(ch,input_file);
		eof_flag=0;
	}
	zero_block_flag=zero_block;
	return record_bytes_read;
}

void zero_buffer() /*function to clear the buffer*/
{
	int tuple_loop;
	buffer[0].length=0;
	strcpy((char*)&buffer[0].data[0],"");
	strcpy((char*)&buffer[0].data[1],"");
	strcpy((char*)&buffer[0].data[2],"");
	strcpy((char*)&buffer[0].data[3],"");
	for(tuple_loop=1; tuple_loop<BUFFER_SIZE;tuple_loop++)
	{
		buffer[tuple_loop].length=0;
		strcpy((char*)&buffer[tuple_loop].data[0],"");
		strcpy((char*)&buffer[tuple_loop].data[1],"");
		strcpy((char*)&buffer[tuple_loop].data[2],"");
		strcpy((char*)&buffer[tuple_loop].data[3],"");
	}
}


/* function to clear the tuple array */

void zero_arrays(int MAX_TABLE_ENTRIES)
{
int tuple_loop;
/* I will consider a dictionary full of zeros initially */
/* Now I am considering a dictionary loaded only location zero*/

tuple[0].length=4;
strcpy((char*)&tuple[0].data[0],"");
strcpy((char*)&tuple[0].data[1],"");
strcpy((char*)&tuple[0].data[2],"");
strcpy((char*)&tuple[0].data[3],"");

tuple[1].length=4;
strcpy((char*)&tuple[1].data[0],"");
strcpy((char*)&tuple[1].data[1],"");
strcpy((char*)&tuple[1].data[2],"");
strcpy((char*)&tuple[1].data[3],"");

for (tuple_loop=2; tuple_loop<MAX_TABLE_ENTRIES; tuple_loop++)
{
	tuple[tuple_loop].length=0;
	strcpy((char*)&tuple[tuple_loop].data[0],"");
	strcpy((char*)&tuple[tuple_loop].data[1],"");
	strcpy((char*)&tuple[tuple_loop].data[2],"");
	strcpy((char*)&tuple[tuple_loop].data[3],"");


}

/*
	strcpy(match_type_code[15].data , "01");     match_type_code[15].length=2;
    strcpy(match_type_code[14].data , "1111");   match_type_code[14].length=4;
    strcpy(match_type_code[13].data , "10110");  match_type_code[13].length=5;
    strcpy(match_type_code[12].data , "110");    match_type_code[12].length=3;
    strcpy(match_type_code[11].data , "10111");  match_type_code[11].length=5;
    strcpy(match_type_code[10].data , "1110");   match_type_code[10].length=4;
    strcpy(match_type_code[9].data , "1010");    match_type_code[9].length=4;
    strcpy(match_type_code[8].data , "");        match_type_code[8].length=0;
    strcpy(match_type_code[7].data , "0010");    match_type_code[7].length=4;
    strcpy(match_type_code[6].data , "000");     match_type_code[6].length=3;
    strcpy(match_type_code[5].data , "0011");    match_type_code[5].length=4;
    strcpy(match_type_code[4].data , "");        match_type_code[4].length=0;
    strcpy(match_type_code[3].data , "100");     match_type_code[3].length=3;
    strcpy(match_type_code[2].data , "");        match_type_code[2].length=0;
    strcpy(match_type_code[1].data , "");        match_type_code[1].length=0;
    strcpy(match_type_code[0].data , "001");        match_type_code[0].length=3;
*/
/*
	strcpy(match_type_code[15].data , "1");          match_type_code[15].length=1;
    strcpy(match_type_code[14].data , "010");        match_type_code[14].length=3;
    strcpy(match_type_code[13].data , "001111");     match_type_code[13].length=6;
    strcpy(match_type_code[12].data , "0010");       match_type_code[12].length=4;
    strcpy(match_type_code[11].data , "001110");     match_type_code[11].length=6;
    strcpy(match_type_code[10].data ,"00110100");    match_type_code[10].length=8;
    strcpy(match_type_code[9].data , "001101011");   match_type_code[9].length=9;
    strcpy(match_type_code[8].data , "");            match_type_code[8].length=0;
    strcpy(match_type_code[7].data , "000");         match_type_code[7].length=3;
    strcpy(match_type_code[6].data , "001100");		 match_type_code[6].length=6;
    strcpy(match_type_code[5].data , "001101010");   match_type_code[5].length=9;
    strcpy(match_type_code[4].data , "");            match_type_code[4].length=0;
    strcpy(match_type_code[3].data , "0011011");     match_type_code[3].length=7;
    strcpy(match_type_code[2].data , "");            match_type_code[2].length=0;
    strcpy(match_type_code[1].data , "");            match_type_code[1].length=0;
    strcpy(match_type_code[0].data , "011");         match_type_code[0].length=3;
*/
/*only 9 match_types*/

	strcpy((char*)match_type_code[15].data , "1");          match_type_code[15].length=1;
    strcpy((char*)match_type_code[14].data , "010");        match_type_code[14].length=3;
    strcpy((char*)match_type_code[13].data , "001111");     match_type_code[13].length=6;
    strcpy((char*)match_type_code[12].data , "0010");       match_type_code[12].length=4;
    strcpy((char*)match_type_code[11].data , "001110");     match_type_code[11].length=6;
    strcpy((char*)match_type_code[10].data ,"");            match_type_code[10].length=0;
    strcpy((char*)match_type_code[9].data , "");            match_type_code[9].length=0;
    strcpy((char*)match_type_code[8].data , "");            match_type_code[8].length=0;
    strcpy((char*)match_type_code[7].data , "000");         match_type_code[7].length=3;
    strcpy((char*)match_type_code[6].data , "001101");		 match_type_code[6].length=6;
    strcpy((char*)match_type_code[5].data , "");            match_type_code[5].length=0;
    strcpy((char*)match_type_code[4].data , "");            match_type_code[4].length=0;
    strcpy((char*)match_type_code[3].data , "001100");      match_type_code[3].length=6;
    strcpy((char*)match_type_code[2].data , "");            match_type_code[2].length=0;
    strcpy((char*)match_type_code[1].data , "");            match_type_code[1].length=0;
    strcpy((char*)match_type_code[0].data , "011");         match_type_code[0].length=3; //repeating match type

	strcpy((char*)miss_type_code[0].data , "1");            miss_type_code[0].length=1;
	strcpy((char*)miss_type_code[1].data , "001");          miss_type_code[1].length=3;
	strcpy((char*)miss_type_code[2].data , "0001");         miss_type_code[2].length=4;
	strcpy((char*)miss_type_code[3].data , "0000");         miss_type_code[3].length=4;
	strcpy((char*)miss_type_code[4].data , "01");           miss_type_code[4].length=2;
	strcpy((char*)miss_type_code[5].data , "");             miss_type_code[5].length=0;

/*financial time series*/
/*
	strcpy((char*)match_type_code[15].data , "1");          match_type_code[15].length=1;
    strcpy((char*)match_type_code[14].data , "");               match_type_code[14].length=0;
    strcpy((char*)match_type_code[13].data , "");               match_type_code[13].length=0;
    strcpy((char*)match_type_code[12].data , "");               match_type_code[12].length=0;
    strcpy((char*)match_type_code[11].data , "");               match_type_code[11].length=0;
    strcpy((char*)match_type_code[10].data ,"");                match_type_code[10].length=0;
    strcpy((char*)match_type_code[9].data , "");                match_type_code[9].length=0;
    strcpy((char*)match_type_code[8].data , "");                match_type_code[8].length=0;
    strcpy((char*)match_type_code[7].data , "");                match_type_code[7].length=0;
    strcpy((char*)match_type_code[6].data , "");		match_type_code[6].length=0;
    strcpy((char*)match_type_code[5].data , "");                match_type_code[5].length=0;
    strcpy((char*)match_type_code[4].data , "");                match_type_code[4].length=0;
    strcpy((char*)match_type_code[3].data , "");                match_type_code[3].length=0;
    strcpy((char*)match_type_code[2].data , "");                match_type_code[2].length=0;
    strcpy((char*)match_type_code[1].data , "");                match_type_code[1].length=0;
    strcpy((char*)match_type_code[0].data , "0");               match_type_code[0].length=1; //repeating match type*/

}


/* function to convert a number to its binary equivalent */
       
void conv_num_to_bin(int number ,int how_many_bits ,string *result)

{
int current_bit_value;
int copy_of_num = number;
int bit_loop;
string binary_zero;
string binary_one;

strcpy((char*)binary_zero.data , "0");							/* string for binary 0 */
binary_zero.length=1;
strcpy((char*)binary_one.data , "1");							/* string for binary 1 */
binary_one.length=1;

result->length=0;
current_bit_value = (int)(0.5+pow(2.0 , (float)(how_many_bits-1)));	/* calculate value of current bit */
for (bit_loop=how_many_bits-1; bit_loop>=0; bit_loop--)				/* loop for each bit */
	{
	if (copy_of_num>=current_bit_value)
		{
		string_cat(result , binary_one);							/* current bit is a one */
		copy_of_num=copy_of_num-current_bit_value;
		}
	else
		string_cat(result , binary_zero);							/* current bit is a zero */
	current_bit_value=current_bit_value/2;							/* move down to next bit */
	}
}


/* function to search the tuple table for a match with the tuple in the literal psoition */
/* the integer returned gives the match position, or if no match is found */
/* then the literal position is returned */

int search_tuple_table()
{
int tuple_loop=0;										/* initialise starting search position */
int found_position=literal_position;					/* initialise found position to the literal position */
int bit_value;
int match_sum;
int current_found_position;
int character_loop;
int smallest_characters_required=4;
string search_tuple;
int best_match_sum=0;
int best_priority=0;
int priority;

match_type=0;
string_copy_sw(&search_tuple , tuple[literal_position]);	/* get tuple from literal position */
/*	if (search_tuple.data[0]==101 && search_tuple.data[1]==32)
			{
				printf("hello");
			}*/
priority = 0;
do
	{
	bit_value=8;
	match_sum=0;
	literal_characters_required=4;

	for (character_loop=0; character_loop<search_tuple.length; character_loop++)
		{

		if (search_tuple.data[character_loop]==tuple[tuple_loop].data[character_loop]&&tuple[tuple_loop].length>=character_loop+1)
			{
			match_sum=match_sum+bit_value;
			literal_characters_required--;
			}
		bit_value=bit_value/2;
		}
	if (match_sum==15)									//full match
	{
		found_position=tuple_loop;
		current_found_position=tuple_loop;
		smallest_characters_required=literal_characters_required;
		best_match_sum=match_sum;
		priority = 8;
		//printf("hit at position %d\n",found_position);
	}
	else
		{
			switch(match_sum)
			{
		/*	    case 14: priority=7; break;   //6 priorities
				case 13: priority=5; break;
				case 12: priority=4; break;
				case 11: priority=5; break;
				case 10: priority=0; break;
				case  9: priority=0; break;
				case  8: priority=1; break;
				case  7: priority=6; break;
				case  6: priority=3; break;
				case  5: priority=0; break;
				case  4: priority=0; break;
				case  3: priority=3; break;
				case  2: priority=0; break;
				case  1: priority=0; break;
				case  0: priority=0; break;*/
			   /* case 14: priority=7; break;   //3 priorities. Almost the same performance less than 0.05 difference on some none in the rest
				case 13: priority=7; break;
				case 12: priority=6; break;
				case 11: priority=7; break;
				case 10: priority=0; break;
				case  9: priority=0; break;
				case  8: priority=0; break;
				case  7: priority=7; break;
				case  6: priority=6; break;
				case  5: priority=0; break;
				case  4: priority=0; break;
				case  3: priority=6; break;
				case  2: priority=0; break;
				case  1: priority=0; break;
				case  0: priority=0; break;*/ 
                                case 14: priority=0; break;   //0 priorities. 
				case 13: priority=0; break;
				case 12: priority=0; break;
				case 11: priority=0; break;
				case 10: priority=0; break;
				case  9: priority=0; break;
				case  8: priority=0; break;
				case  7: priority=0; break;
				case  6: priority=0; break;
				case  5: priority=0; break;
				case  4: priority=0; break;
				case  3: priority=0; break;
				case  2: priority=0; break;
				case  1: priority=0; break;
				case  0: priority=0; break;
				}
		if (priority>best_priority) 
		{
		best_match_sum=match_sum;
		smallest_characters_required=literal_characters_required;
		current_found_position=tuple_loop;
		best_priority=priority;
		}
		}
	tuple_loop++;
	}
 // while ((tuple_loop<literal_position) && (found_position != old_found_position) && (tuple[tuple_loop].length>0));
 	while ((tuple_loop<literal_position) && (found_position==literal_position) && (tuple[tuple_loop].length>0));

if (best_match_sum>0)
	{
	if (search_tuple.length == tuple[current_found_position].length) /*same length*/
	{
		switch(best_match_sum)
		{
		case 14: if (search_tuple.length == 3) {best_match_sum = 15;} break;
		case 12: if (search_tuple.length == 2) {best_match_sum = 15;}  break; /*total*/
		case 8:	/*if (search_tuple.length == 1) {best_match_sum = 15;} else { */best_match_sum = 0;current_found_position = literal_position;/*}*/ break;
		}
	}
	else
	{
		if(best_match_sum == 8)
			{ 
				best_match_sum = 0;
				current_found_position = literal_position;
			} 	
	}
	if (best_match_sum != 15 /*&& tuple[literal_position].data[0] == 32  */ && tuple[literal_position].length < 4)
	{
		best_match_sum = 0; 
		current_found_position = literal_position;
	}
	match_type=best_match_sum;
	found_position=current_found_position;
	literal_characters_required=smallest_characters_required;
	switch(match_type)
		{
		case 15: match_bits_to_output=2; break;
		case 14: match_bits_to_output=4; break;
		case 13: match_bits_to_output=5; break;
		case 12: match_bits_to_output=3; break;
		case 11: match_bits_to_output=5; break;
		case 10: match_bits_to_output=4; break;
		case  9: match_bits_to_output=4; break;
		case  8: match_bits_to_output=0; break;
		case  7: match_bits_to_output=4; break;
		case  6: match_bits_to_output=3; break;
		case  5: match_bits_to_output=4; break;
		case  4: match_bits_to_output=0; break;
		case  3: match_bits_to_output=3; break;
		case  2: match_bits_to_output=0; break;
		case  1: match_bits_to_output=0; break;
		case  0: match_bits_to_output=0; break;
		}
	}
else
	{
	match_bits_to_output=0;
	}





/*detection of match at any location*/										/*at least 2 repeticions coded with code 0 5 with code 3*/					
if ((tuple_number!=0) && ((old_found_position == found_position ) && (match_type == 15) && ((repeticion < (pow(2.0, MAX_BITS_REPIT)+1))  || ((repeticion < (pow(2.0, MAX_BITS_REPIT_ZERO)-1)) && old_found_position == 0)) && repeticion >= 1))
{
	repeticion++;
	repeticion_active = 1;
        //printf("repeticion at %d with value %d\n", old_found_position,repeticion);
}

else
{
	repeticion_active =0;
}

position_hits[found_position]++;



return found_position;
}



/* function to implement the tuple movement strategy */
/* this is currently a move to front strategy */

void move_to_front(int found_position,int MAX_TABLE_ENTRIES)


{
	int tuple_loop;
	string temporary_tuple;

	string_copy_sw(&temporary_tuple , tuple[literal_position]);	/* store tuple */

	if ((aoa_adaptation > found_position || old_match_type!=15) && (found_position<(MAX_TABLE_ENTRIES)))
	{
		found_position++;
	}

/*	aoa_adaptation = found_position;
	old_match_type = match_type;*/

	if (((aoa_adaptation ==0 && match_type!=15) || (old_match_type!=15)) && (literal_position<(MAX_TABLE_ENTRIES)))
	{
		literal_position++;	/* if a miss, increment the literal position if we can, i.e we add the new tuple to the table */
	}

//	literal_position++;

	if (old_match_type==15) /*take care*/
	{
		for (tuple_loop=aoa_adaptation; tuple_loop>0; tuple_loop--)
		{
			if (tuple_loop!=literal_position)
			{
				tuple[tuple_loop]=tuple[tuple_loop-1];		/* move tuple down one position */
			}
		}
		string_copy_ww(&tuple[1] , tuple[0]);
		string_copy_ws(&tuple[0] , temporary_tuple);			/* move matched tuple to front of table */
	}
	else
	{
		for (tuple_loop=(literal_position-1); tuple_loop>0; tuple_loop--)
		{
			tuple[tuple_loop]=tuple[tuple_loop-1];			/* move tuple down one position */
		}
		string_copy_ws(&tuple[0] , temporary_tuple);			/* move search tuple to front of table */
	}
aoa_adaptation=found_position;
old_match_type=match_type;

}


/* Funtion to convert from bytes to bits */
void ch_bytobi(string buffer,int fin)
{
	int counter=0,l=0,length_for=0,last,i;
	unsigned char new_byte=0x00;
	/*char last_length;*/
	if(fin==1)
		length_for=buffer.length;
	else
		length_for=64;
	last=length_for;
	for(l=0;l<length_for;l++)
	{
		if (buffer.data[l] =='1')
		{    
			new_byte=(new_byte | 0x1);  
			counter++;
		}	
		else
			counter++;
		if(counter==8)
		{
			fputc(new_byte,output_file_comp);
			counter=0;
			last=last-8;
		}
		if((fin==1)&&(l==length_for-1))
		{
			for(i=0;i<8-counter;i++)
			{
				new_byte=new_byte<<1;
				total_output_bits++;
				new_byte=(new_byte | 0x1);
				
			}
			fputc(new_byte,output_file_comp);
			/*strcpy(last_length,char(counter));*/
			fputc(counter,output_file_comp);
			total_output_bits+=8;
		}
		new_byte=new_byte<<1;
	}
	if (length_for == 0) // add one last byte with number of bits valid anyway
	{
			fputc(8,output_file_comp);
			total_output_bits+=8;
    }
}    



/* function to update the bit count to the output file */

void update_bit_count(int block_size, int found_position, int actual_match_type, int MAX_TABLE_ENTRIES, int tuple_number, int tuples_read)
{
	string tuple_byte[4];
	int byte_loop;
	string one,zero;
	strcpy((char *)one.data,"1");
	one.length=1;
	strcpy((char *)zero.data,"0");
	zero.length=1;
	conv_num_to_bin((int)tuple[literal_position].data[0],8,&(tuple_byte[3])); //split incoming tuple into its individual bytes
	conv_num_to_bin((int)tuple[literal_position].data[1],8,&(tuple_byte[2]));
	conv_num_to_bin((int)tuple[literal_position].data[2],8,&(tuple_byte[1]));
	conv_num_to_bin((int)tuple[literal_position].data[3],8,&(tuple_byte[0]));

	if (repeticion == 1) /*single full match at location zero*/
	{
		if (old_tuple.length == 1) /*this is a miss of a single byte*/
		{
			misses++;
			string_cat(&output_buffer,one);
			output_bits++;
			block_output_bits++;
			switch(old_tuple.length)
			{
			case(1):
				string_cat(&output_buffer, miss_type_code[0]);
				block_output_bits=block_output_bits+miss_type_code[0].length;
				output_bits=output_bits+miss_type_code[0].length;
				miss_type_hits[0]++;
				break;
			default:
				printf("fatal error ilegal length\n");
				break;
			}
			
		}
		else
		{
			hits++;
			if (old_found_position < twokminusrow)			/* this code is for a hit - generate the phased code for the hit location */
			{
				conv_num_to_bin(old_found_position , k , &temp_string);
				output_bits = output_bits+k+match_type_code[15].length; /*two bits for a full match*/

			}
			else
			{
				conv_num_to_bin(old_found_position+twokminusrow , k+1 , &temp_string);
				output_bits = output_bits+k+1+match_type_code[15].length; /*two bits for a full match*/
			}
			match_type_hits[15]++;
			string_cat(&output_buffer,temp_string); /*location zero*/
			string_cat(&output_buffer,match_type_code[15]); //add match type code to output buffer
		
			if(output_buffer.length>=64)
			{
				ch_bytobi(output_buffer,0);
				left_shift_string(&output_buffer,64);
			}
		}	
		repeticion = 0;
	}


	if (repeticion > 1) 
	{
		if (old_found_position < twokminusrow)			/* this code is for a hit - generate the phased code for the hit location */
		{	
			conv_num_to_bin(old_found_position,k,&temp_string);
			output_bits = output_bits + k + match_type_code[0].length;
		}
		else
		{
			conv_num_to_bin(old_found_position+twokminusrow , k+1 , &temp_string);
			output_bits = output_bits + k + 1 + match_type_code[0].length;
		}
		string_cat(&output_buffer,temp_string); /*location*/
		string_cat(&output_buffer,match_type_code[0]); /*repeating match type*/
		switch (old_found_position)
		{
			case 0 : 
				output_bits = output_bits+(int)MAX_BITS_REPIT_ZERO; 
				conv_num_to_bin(repeticion,(int)MAX_BITS_REPIT_ZERO,&temp_string);			
				break; 
			default :
				output_bits = output_bits+(int)MAX_BITS_REPIT; 
				hits++; 
				match_type_hits[0]++; 
				if (repeticion > 3)
					repeticion = repeticion - 4;
				conv_num_to_bin(repeticion,(int)MAX_BITS_REPIT,&temp_string);
				break;
		}
		string_cat(&output_buffer,temp_string); /*number of repeticions*/
		if(output_buffer.length>=64)
		{
			ch_bytobi(output_buffer,0);
			left_shift_string(&output_buffer,64);
		}
		repeticion = 0;
	}

	row=literal_position+1;										/* number of different codes required */
	k=(int)(0.9999+(log((double)literal_position))/log(2.0)); /* ROUNDUP of log2(row) */
	twokminusrow=(int)(pow(2.0 , (double)k))-literal_position;	/* 2**k - row (+1 as literal position is always present) */
	

	if(match_type!=15 || (eof_flag == 1 && tuple_number == tuples_read-1 && repeticion_active == 0) || (tuple_number == tuples_read-1 && total_bytes_read >= block_size && repeticion_active == 0))
	{
		/*if(((tuple_number == tuples_read-1 && total_bytes_read >= block_size) && (repeticion_active==0)) || !((tuple_number == tuples_read-1 && total_bytes_read >= block_size) && (repeticion_active == 0)))
		{*/
			if (found_position==literal_position)
			{
				misses++;
				if (literal_position>0)
				{
					string_cat(&output_buffer,one);
					output_bits++;
					block_output_bits++;
				}
				if (!(tuple_number == tuples_read-1 && eof_flag == 1))
				{
					switch(tuple[literal_position].length)
					{
					case(0):
						break;
					case(1):
						output_bits=output_bits+miss_type_code[0].length;
						miss_type_hits[0]++;
					    block_output_bits=block_output_bits+miss_type_code[0].length;
						string_cat(&output_buffer, miss_type_code[0]);
						break;
					case(2):
						output_bits=output_bits+8+miss_type_code[1].length;
						miss_type_hits[1]++;
					    block_output_bits=block_output_bits+8+miss_type_code[1].length;
						string_cat(&output_buffer, miss_type_code[1]);					
						string_cat(&output_buffer, tuple_byte[3]);		
						break;
					case(3):
						output_bits=output_bits+16+miss_type_code[2].length;
						miss_type_hits[2]++;
					    block_output_bits=block_output_bits+16+miss_type_code[2].length;
					 	string_cat(&output_buffer, miss_type_code[2]);	
						string_cat(&output_buffer, tuple_byte[3]);
						string_cat(&output_buffer, tuple_byte[2]);		
						break;
					case(4):
						if (USE_PARSER == 1)
						{
							if (active_parser == 1)
							{
								if (tuple[literal_position].data[3] == PARSER)
								{
									output_bits=output_bits+24+miss_type_code[3].length;
									miss_type_hits[3]++;
								 	string_cat(&output_buffer, miss_type_code[3]);
									string_cat(&output_buffer, tuple_byte[3]); //add full tuple to output buffer
									string_cat(&output_buffer, tuple_byte[2]);
									string_cat(&output_buffer, tuple_byte[1]);
								}
								else
								{
									output_bits=output_bits+32+miss_type_code[4].length;
									string_cat(&output_buffer, miss_type_code[4]);
									string_cat(&output_buffer, tuple_byte[3]); //add full tuple to output buffer
									string_cat(&output_buffer, tuple_byte[2]);
									string_cat(&output_buffer, tuple_byte[1]);
									string_cat(&output_buffer, tuple_byte[0]);
									miss_type_hits[4]++;
								}
							}
							else
							{
									output_bits=output_bits+32+miss_type_code[4].length;
									string_cat(&output_buffer, miss_type_code[4]);
									string_cat(&output_buffer, tuple_byte[3]); //add full tuple to output buffer
									string_cat(&output_buffer, tuple_byte[2]);
									string_cat(&output_buffer, tuple_byte[1]);
									string_cat(&output_buffer, tuple_byte[0]);
									miss_type_hits[4]++;
							}

						}
						else
						{
							output_bits = output_bits+32;
							string_cat(&output_buffer, tuple_byte[3]); //add full tuple to output buffer
							string_cat(&output_buffer, tuple_byte[2]);
							string_cat(&output_buffer, tuple_byte[1]);
							string_cat(&output_buffer, tuple_byte[0]);
						}
						break;
					}
				}
				else
				{
				    if(USE_PARSER == 1)
					{
						output_bits=output_bits+32+miss_type_code[4].length;
						string_cat(&output_buffer, miss_type_code[4]);
					}
					else
					{
						output_bits=output_bits+32;
					}
					switch(tuple[literal_position].length)
					{
						case(0):
							break;
						case(1):
							string_cat(&output_buffer, tuple_byte[3]);
							break;
						case(2):
							string_cat(&output_buffer, tuple_byte[3]);
							string_cat(&output_buffer, tuple_byte[2]);
						break;
						case(3):
							string_cat(&output_buffer, tuple_byte[3]);
							string_cat(&output_buffer, tuple_byte[2]);
							string_cat(&output_buffer, tuple_byte[1]);
						break;
						case(4):
							string_cat(&output_buffer, tuple_byte[3]); //add full tuple to output buffer
							string_cat(&output_buffer, tuple_byte[2]);
							string_cat(&output_buffer, tuple_byte[1]);
							string_cat(&output_buffer, tuple_byte[0]);
						break;
					}
				}	
			}
			else
			{
			
				hits++;
				if (found_position<twokminusrow)
				{		
					conv_num_to_bin(found_position,k,&temp_string);
					string_cat(&output_buffer,temp_string);
					output_bits=output_bits+k;				/* add in bit length of code sent out */
					block_output_bits=block_output_bits+k;	/* add in bit length of code sent out to block total */
				}
				else
				{
					conv_num_to_bin(found_position+twokminusrow,k+1,&temp_string);
					string_cat(&output_buffer,temp_string);
					output_bits=output_bits+k+1;
					block_output_bits=block_output_bits+k+1;
				}
				string_cat(&output_buffer,match_type_code[actual_match_type]); //add match type code to output buffer
				match_type_hits[actual_match_type]++;
				output_bits=output_bits+match_type_code[actual_match_type].length;
				block_output_bits=block_output_bits+match_type_code[actual_match_type].length;

				if (match_type!=15)
				{
					conv_num_to_bin(actual_match_type,4,&temp_string);
					for(byte_loop=3;byte_loop>=4-tuple[literal_position].length;byte_loop--)
					{
						if(temp_string.data[3-byte_loop]==48) //add literal characters to output buffer where necessary
						{
							string_cat(&output_buffer,tuple_byte[byte_loop]);
							output_bits=output_bits+8;
						}
					}
				
					block_output_bits=block_output_bits+8*literal_characters_required;
				}
			}
		/*}*/
	
	}
	else
	{
		repeticion = 1; /*full match*/
		old_tuple = tuple[literal_position];
	}
	if(output_buffer.length>=64)
	{
		ch_bytobi(output_buffer,0);
		left_shift_string(&output_buffer,64);
	}

old_found_position = found_position;
}


/* start of main program */

int main(int argc, char *argv[])
{

//int dictionary_size, int block_size, int parser, CString selected[], CListBox *displaybox, CListBox *summary, int selection_count)

   clock_t start, finish;
//   double  duration;
	int times;
	int dictionary_size;
	int block_size;
	int parser;
	double cr=0;
	double average_performance = 0;
	double total_input_bytes = 0;
	double total_output_bytes = 0;
	int i=0,num_file=0;
	int tuples_read;
	int total_tuples_local;
	double total_tuples;
	int tuple_position;
	int running;
	int block;
	int total_files = 0;
	int terminating_tuple_position;
	int bytes_read;
	int file_is_compressed=0;
	double compr[100];
	char *aux_string=0;
	//char first_string[1000];
	aux_string = malloc(1000); // for string manipulation

	printf("X-MatchPROvw 5.2 compressor\n");


	if(argc<5)
	{

		printf("Incorrect number of parameters\n");
		printf("xmw52c <dic size> <block size> <parser> <in file[s]>\n");
		printf("Dictionary sizes can be set to any value up 4096\n");
		printf("Parser can have the value 0 (inactive), value 1 (active) or value 2 (active dynamically => recomended)\n");

		printf("X-MatchPROvw compresses blocks of <block_size> bytes at a time and adds the word 'pro' to form the output file name \n");
		printf("Please report any bugs at J.L.Nunez-Yanez@lboro.ac.uk\n");
		exit(1);

	}


	num_file=0;


	dictionary_size = atoi(argv[1]);
	block_size = atoi(argv[2]);
	parser = atoi(argv[3]);

	for(i=0;i<100;i++)
		compr[i]=0.0;

	if (block_size==0)
	{
		printf("error - can't run in unblocked mode!\n");
		exit(1);
	}
	if(block_size <4)
	{
			printf("error - block size minimum is 4\n");
			exit(1);
	}
	if(block_size > 500000)
	{
		printf("error - maximum block size is 500000\n");
		exit(1);
	}


	if (parser == 2)
	{
		USE_PARSER = 1;
		CHANGE_PARSER = 1;
		printf("Parser active dynamically !!\n\n");
	}
	else if (parser == 1)
	{
		USE_PARSER = 1;
		CHANGE_PARSER = 0;
		printf("Parser active !!\n\n");
	}
	else
	{
		USE_PARSER = 0;
		CHANGE_PARSER = 0;
		printf("Parser inactive !!\n\n");
	}
/*
	if(!(frequency = fopen("./frequencies.txt","w")))		// open compression vector file for reading
	{
		printf("Fatal error: fail to open frequency file for writting\n\n");
		exit(1);
	}
*/
	switch(dictionary_size)
	{
	case 8:
	case 16:
	case 32:
	case 64:
	case 128:
	case 256:
	case 512:
	case 1024:
	case 2048:
	case 3072:
	case 4096:
		{

			printf("Dictionary Size: %d\n",dictionary_size);
			printf("Block Size: %d\n",block_size);
	    	break;
		}
	default:
		{
			printf("Ilegal dictionary size - PROGRAM TERMINATED\n");
			exit(1);
		}
	}

	start = clock();
	cr=0;


	for (times=4;times<argc ;times++)
	{
		strcpy(name_of_input_file , argv[times]);			/* get name of input file from command line */
		strcpy(name_of_output_file, argv[times]);
		int i = 0;
		strcat(name_of_output_file, "pro");

		literal_position=1; /*0 is full of zeros, RLI as a match type not reserved location*/
		total_output_bits=0;
		output_bits=0;
		input_bits=0;
		bytes_read=0;
		total_tuples = 0;
		number_of_blocks=0;
		eof_flag = 0;
		i=0;
		file_is_compressed=0;

		printf("Input  file: %s\n",name_of_input_file);
		printf("Output  file: %s\n\n",name_of_output_file);

		//long double file_size;


		if(!(input_file=fopen(name_of_input_file, "rb")))		// open compression vector file for reading
		{
			printf("Fatal error: fail to open input file for reading\n");
			exit(1);
		}

		if(!(output_file_comp=fopen(name_of_output_file, "wb")))		// open compression vector file for reading
		{
			printf("Fatal error: fail to open output file for writting\n");
			exit(1);
		}

													/* zero arrays */
		characters_read=0;											/* clear characters_read */
		running=1;

		do
		{
			total_bytes_read=0;
			total_tuples_local = 0;
			zero_arrays(dictionary_size); /*RLI no plus one*/
			literal_position = 1; /*one for 0 none for RLI*/
			if (parser == 1)
				active_parser = 1;
			else
				active_parser = 0;
			switch_parser = CHANGE_PARSER;
			row=literal_position+1;										/* number of different codes required */
			k=(int)(0.9999+(log((double)literal_position))/log(2.0)); /* ROUNDUP of log2(row) */
			twokminusrow=(int)(pow(2.0 , (double)k))-literal_position;	/* 2**k - row (+1 as literal position is always present) */
			repeticion_active=0;
			repeticion=0;

			aoa_adaptation=0; /*for each block size*/
			old_match_type=15;
			old_found_position=0;
			old_tuple = tuple[0];
			number_of_blocks++;

			do
			{
				zero_buffer();
				tuples_read = 0;
				bytes_read=get_next_block(&tuples_read, block_size);
				input_bits=input_bits+8*bytes_read;

				/*if(number_of_blocks==217)
				{
					printf("hello");
				}*/
				/* no special treatment to zero blocks*/
				output_bits=0;

				for (tuple_number=0; tuple_number<tuples_read; tuple_number++)
				{

						string_copy_ww(&tuple[literal_position] , buffer[tuple_number]);	/* get next tuple from buffer */
						tuple_position=search_tuple_table();/* find tuple position in table */
						terminating_tuple_position = old_found_position;
						total_tuples_local ++;
					/*	if (total_tuples_local == 250 && block == 5)
						{
							printf("hello");
						}*/
						if (repeticion_active == 0 || (eof_flag == 1 && tuple_number == tuples_read-1) || (tuple_number == tuples_read-1 && total_bytes_read >= block_size))
						{
							update_bit_count(block_size,tuple_position,match_type, dictionary_size,tuple_number, tuples_read);				/* update number of output bits */
						}
						if (tuple[literal_position].length != 1)
							move_to_front(tuple_position, dictionary_size);								/* move tuple to front of table */

				}

				/*output_bits=output_bits+8*(bytes_read-4*buffer_entries);		 add in any remaining bytes literally (non-full block) */
				total_output_bits=total_output_bits+output_bits;
				total_tuples = tuples_read + total_tuples;
				/*if ( total_output_bits > 5000000)
					printf("hello");*/
			}while ( total_bytes_read < block_size && eof_flag==0);

			/*if(repeticion > 0 && terminating_tuple_position != tuple_position)*/
			/*{
				printf("error");
				update_bit_count(tuple_position,match_type, dictionary_size,tuple_number, buffer_entries);				 update number of output bits
			}*/
			block ++;


		}while (eof_flag==0);



	//	summary->DeleteString(string_number);

		finish = clock();

		fclose(input_file);

		ch_bytobi(output_buffer,1);								/* output the remaining bits of the output buffer */
		left_shift_string(&output_buffer,output_buffer.length);	/* shift the remaining shifts of the output buffer */

		fclose(output_file_comp);

		printf("Size of input  file: %d bits\n", (int)input_bits);
		printf("Size of output  file: %d bits\n", (int)total_output_bits);

		if((double)input_bits > 0)
		{

			cr=((double)total_output_bits/(double)input_bits)+cr;
			total_output_bytes = (double)total_output_bits / 8.0 + total_output_bytes;
			total_input_bytes = (double)input_bits / 8.0 + total_input_bytes;
			average_performance = average_performance + (4*(((double)input_bits/32.0)/(double)total_tuples));

			printf("Compression Ratio: %f\n", (double)total_output_bits/(double)input_bits);

			printf("Performance: %f bytes/cycle\n\n", (4*(((double)input_bits/32.0)/(double)total_tuples)));
			total_files ++;
		}
		else
		{
			printf("This file is empty an it will be ignored\n");
		}


	} /*End of time loop*/


		printf("Global CR (arithmetic mean): %f\n", (float)cr/total_files);
		printf("Global CR (weighted mean): %f\n", (float)total_output_bytes/total_input_bytes);

		printf("Average Performance: %f bytes/cycle\n", (float)average_performance/total_files);

		double duration;

		duration = (double)(finish - start) / CLOCKS_PER_SEC;
		printf("It took: %f seconds to process the file(s)\n\n\n",duration);
		//        printf( "\nIt took %2.1f seconds to process the file(s)\n", duration );

	/*	for (i=0;i<dictionary_size;i++)
		{
			//printf("Percentage hits on position %d is %f\n",i,(float)position_hits[i]/(hits+misses));
			printf("Hits on position %d is %f\n",i,(float)position_hits[i]);
			percent=(float)miss_type_hits[i]/misses;
			fprintf(frequency,"%f\n",percent);
		}
		
                long double total = hits+misses;
                printf("Hits %f and misses %f and total %f\n",(float)hits,(float)misses,(float)total);
		fprintf(frequency,"match type frequencies\n");
		for (i=0;i<16;i++)
		{
			printf("Percentage match type %d is %f\n",i,(float)match_type_hits[i]/(float)hits);
			percent=(float)match_type_hits[i]/hits;
			fprintf(frequency,"%f\n",percent);
		}
		fclose(frequency);*/

//		printf("Compression done!\n");

		/*compr[num_file]=cr;
		num_file++;*/


		//free(aux_string);


	exit(0);
}

