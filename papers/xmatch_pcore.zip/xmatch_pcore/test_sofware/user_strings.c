/* this contains a set of functions to aid string processing		*/
/* the length of the string is stored along with the data			*/
/* such that characters such as ascii 0 can be dealt with correctly */

#include "user_strings.h"
#include <stdio.h>

/* string_copy(destination , source). Copies source into destination, source remains unchanged */
/* Modif. con * */


void string_copy_ss(string *destination ,string source)

{
int l;
for (l=0; l<source.length; l++)
	destination->data[l]=source.data[l];
destination->length=source.length;
}

void string_copy_sw(string *destination ,word source)

{
int l;
for (l=0; l<source.length; l++)
	destination->data[l]=source.data[l];
destination->length=source.length;
}

void string_copy_ww(word *destination ,word source)

{
int l;
for (l=0; l<source.length; l++)
	destination->data[l]=source.data[l];
destination->length=source.length;
}

void string_copy_ws(word *destination ,string source)

{
int l;
for (l=0; l<source.length; l++)
	destination->data[l]=source.data[l];
destination->length=source.length;
}



/* string_compare(str1 , str2). Returns integer 1 if strings str1 and str2 */
/* are EXACTLY equal, i.e same length and characters, 0 otherwise. */

int string_compare(string str1 ,string str2)

{
int l;
int equal=1;
if (str1.length!=str2.length)
	equal=0;
else	for (l=0; l<str1.length; l++)
		if (str1.data[l]!=str2.data[l])
			equal=0;
return equal;
}



/* string_cat(destination , source). Concatenates source string on the end */
/* of destination string. Source string remains unchanged */

void string_cat(string *destination , string source)
{
	int l;
	for (l=destination->length; l<(destination->length+source.length); l++)
	{
		destination->data[l]=source.data[l-destination->length];
	}
	destination->length=destination->length+source.length;
}




/* left_string(destination , source , n). Returns in destination the left most */
/* n characters of source. Source remains unchanged */

void left_string(string *destination ,string source ,int n)	

{
int l;
for (l=0; l<n; l++)
	destination->data[l]=source.data[l];
destination->length=n;
}



/* right_string(destination , source , n). Returns in destination the right most */
/* n characters of source. Source remains unchanged */

void right_string(string destination ,string  source ,int n)	

{
int l;
int p;
p=source.length-n;
for (l=0; l<n; l++)
	destination.data[l]=source.data[l+p];
destination.length=n;
}



/* print_string(source). Prints out the string supplied surrounded by quotes */
/* null characters are printed as ? */

void print_string(string * source)	

{
int l;
printf("\"");
for (l=0; l<source->length; l++)
	if ((source->data[l]<32) || ((source->data[l]>126) && (source->data[l]<160)))
		printf("?");
	else	printf("%c" , source->data[l]);
printf("\"");
}



/* string_print(source). Prints out the string on its own */
/* null characters are printed as ? */

void string_print(string *source)

{
int l;
for (l=0; l<source->length; l++)
	if ((source->data[l]<32) || ((source->data[l]>126) && (source->data[l]<160)))
		printf("?");
	else	printf("%c" , source->data[l]);
}



/* left_shift_string(source , n). Shifts characters in source n places left */

void left_shift_string(string * source ,int n)

{
	int loop;
	int size=source->length;
	for (loop=n; loop<size; loop++)
	{
		source->data[loop-n]=source->data[loop];
	}
	source->length=size-n;
}



/* right_shift_string(source , n). Shifts characters in source n places right */
/* zeroes are entered into the left hand end of the string */
void right_shift_string(string *source , int n)

{
int loop;
int size=source->length;
for (loop=(size+n-1); loop>=n; loop--)
	{
	source->data[loop]=source->data[loop-n];
	}
for (loop=(n-1); loop>0; loop--) //ojo
	{
	source->data[loop]=48;
	}
source->length=size+n;
}



