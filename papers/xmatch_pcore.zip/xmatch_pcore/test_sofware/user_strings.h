
/* define my own string type, as we need lengths up to 96 characters */
typedef struct
{
	signed short length;
	unsigned char data[130];
}
string;

typedef struct
{
	signed short length;
	unsigned char data[10];
}
word;
