
/* X-MatchPRO revision                       */
/* Revision 3.0 by Jose Nunez November 1999  */
/* characteristics :                         */ 
/* No phase binary coding                    */
/* dictionary size : 64 (270) 32(180) 16(130)*/
/* new adaptation adaptation mechanism       */
/* X-MatchPRO is incompative with other forms*/
/* of X-Match                                */
/* Revision 3.0 includes RLI technique       */

/* This code is supplied exactly "as is" without any implications about			*/
/* anything whatsoever! It must not be used for publication of results using	*/
/* the X-Match algorithm without due ackdnowledgement and reference, and it must	*/
/* not be redistributed under ANY circumstances. Your cooperation is			*/
/* appreciated in these matters.												*/


/* The table length is variable and begins with no entries, thus the first		*/
/* tuple in each data stream is sent literally without any prefix code.			*/
/* A table miss causes the table to be expanded by one entry, whereas a table	*/
/* hit requires no table expansion. The literal (miss) position is always the	*/
/* last location in the table. Phased binary coding is used to represent table	*/
/* positions, with the literal position always coded in 1 bit (a '1').			*/

/* The coding used is a phased binary code which is defined as follows -		*/
/* The literal position is always the last location in the table, thus we must	*/
/* be able to code positions from the range 0 <= position < literal_positiond+1	*/
/* Let row = literal_positiond+1													*/
/* let kd = ROUNDUP(log2 row)													*/
/* now if position < (2**kd - row) then code position using kd bits				*/
/* otherwise code (position + (2**kd - row)) using kd+1 bits						*/
/* Thus the codes are phased in as the length of the table grows.				*/
/* This method takden from "Text Compression", Bell, Cleary, Witten; pp 293		*/

/* Operates on blockded data, but blockds full of zeroes are OMITTED FROM THE		*/
/* RESULTS, except that a count is kdept of the number of such blockds.			*/
/* Workds on all file sizes, i.e file size does not have to be an exact multiple	*/
/* of the blockd size.															*/
/*																				*/
/* number_of_tuples = size in bytes of the input data blockd   		       		*/
/* input_filed = name of file to be compressed			              			*/

#define PARSER 32
#define TOP_TABLE_ENTRIES 4097	/* the ABSOLUTE MAXIMUM SIZE in entries of the table */
#define MAX_BITS_REPIT 2 /*the number of bits use to code run lengths*/
#define MAX_BITS_REPIT_ZERO 8
/*RLI reserves one location for run lengths*/

/* set up libraries to be used */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include "user_strings.h"





int aoa_adaptationd; /*variable that holds the value to perform out of order adaptation*/

FILE *input_filed;			        /* compressed file */
FILE *output_file_desc;             /* decompressed file */

char name_of_input_filed[1000];		/* name of compressed input file */
char name_of_output_filed[1000];		/* name of output file to be decompressed */
string temp_stringd;					/* temporary string */

string c_dataout_string;			/* compressed data out */
string next_c_dataout_string;		/* compressed data out next cycle (current c_dataout does not appear until the next cycle) */
string zero;						/* binary 0 */
string decoded_tuple;

string ram_data;					/* memory data at the current address */

int characters_readd;				/* used to store the number of characters read in a blockd */
int tuples_read;					/* the number of tuples read */
int parser_active;					/*active or inactive*/

string tuple[TOP_TABLE_ENTRIES];	/* array of tuple characters */
string input_buffer;				/* buffer to store bits read from RAM */
int address;						/* RAM address */
int literal_positiond;				/* the position of the literal code (last in table) */

long double input_bitsd=0;					/* number of bits read in from the data file */
long double output_bitsd=0;					/* number of bits output to the compressed file */
long double blockd_input_bitsdd=0;
long double blockd_output_bitsdd=0;
long double blockd_total_bitsd=0;
long double blockds_that_compressd=0;
long double number_of_blockdsd=0;


int tuple_position;
int old_match_typed; /*out of order adaptation storage of the match types*/
int match_typed;
int miss_type;

int match_bits_to_outputd;
int literal_characters_requiredd;

int kd,twokdminusrowd;

/*flags when repeating*/

int run_length_detected;
int repeticion_number;

typedef struct
{
	int word[4];					/* ram cell consists of 4 x 16 bit words - i.e 64 bits in total */
	int length; /*bits valid in word*/
}ram_matrix;

ram_matrix ram_array[8192];			/* ram array is 8kd x 64 */

int underflow;

long double hitsd=0;
long double missesd=0;



extern void string_cat(string *destination , string source);
extern void print_string();
extern void string_copy_ss(string *destination ,string source);
extern void string_copy_sw(string *destination ,word source);
extern void string_copy_ww(word *destination ,word source);
extern void string_copy_ws(word *destination ,string source);
extern void left_shift_string(string * source ,int n);
extern void left_string(string *destination ,string source ,int n);








/* function to clear the tuple array */

void zero_arraysd(int MAX_TABLE_ENTRIES)
{
int tuple_loop;


/*load only location zero*/
/* I will consider a dictionary full of zeros initially */
/* Now I am considering a dictionary preloaded with different data*/




for (tuple_loop=0; tuple_loop<MAX_TABLE_ENTRIES; tuple_loop++)
{
	tuple[tuple_loop].length=4;
	strcpy((char*)&tuple[tuple_loop].data[0],"");
	strcpy((char*)&tuple[tuple_loop].data[1],"");
	strcpy((char*)&tuple[tuple_loop].data[2],"");
	strcpy((char*)&tuple[tuple_loop].data[3],"");
}


}



/* function to convert a number to its binary equivalent */

void conv_num_to_bind(int number ,int how_many_bits ,string *result)

{
	int current_bit_value;
	int copy_of_num = number;
	int bit_loop;
	string binary_zero;
	string binary_one;

	strcpy((char*)binary_zero.data , "0");							/* string for binary 0 */
	binary_zero.length=1;
	strcpy((char*)binary_one.data , "1");							/* string for binary 1 */
	binary_one.length=1;

	result->length=0;
	current_bit_value = (int)(0.5+pow(2.0 , (float)(how_many_bits-1)));	/* calculate value of current bit */
	for (bit_loop=how_many_bits-1; bit_loop>=0; bit_loop--)				/* loop for each bit */
	{
		if (copy_of_num>=current_bit_value)
		{
			string_cat(result , binary_one);							/* current bit is a one */
			copy_of_num=copy_of_num-current_bit_value;
		}
		else
			string_cat(result , binary_zero);							/* current bit is a zero */
		current_bit_value=current_bit_value/2;							/* move down to next bit */
	}
}



/* function to convert a binary string to its equivalent decimal number */
/* returns the integer value */

int conv_bin_to_num(string number ,int how_many_bits)

{
	int result;
	int bit_loop;
	int bit_value;

	result=0;
	bit_value=1;

	for (bit_loop=(how_many_bits-1); bit_loop>=0; bit_loop--)
	{
		if (number.data[bit_loop]==49)
			result=result+bit_value;

		bit_value=bit_value*2;
	}
	return result;
}



/* function to read in RAM data from the compression test vector file */

int read_data_into_ram()
{

	string this_data;

	unsigned new_char=0;
	unsigned old_char=0;
	int i,j,new_bit;

	int local_address;
	int current_address;
	string old_data;
	int word_loop;
	int word_value;

	int bits_read; /*last one is not 64 bits en length*/

	//int comp=1,sale_ya=0;
	//int old_comp=1;
	int num_reads=0;

	for (current_address=0; current_address<8192; current_address++)
	{
		for (word_loop=0; word_loop<4; word_loop++)
			ram_array[current_address].word[word_loop]=rand() % 65536;		// fill ram_array with random data
	}
	local_address=0;

	do
	{
		bits_read=0;
		for(i=0;i<8;i++)							// read in a vector from the input (compressed) vector file
		{

			new_char=(unsigned)fgetc(input_filed);

			fseek(input_filed,1,1);
			old_char=(unsigned)fgetc(input_filed);
			if(feof(input_filed))
			{
				fseek(input_filed,-1,1);
				old_char=(unsigned)fgetc(input_filed);
				bits_read=bits_read+old_char-8; /*it reads one to much*/
			    old_char=(unsigned)fgetc(input_filed);
			}
			else
			{
				fseek(input_filed,-2,1);
			}
			bits_read=bits_read+8;
			for(j=0;j<8;j++)
			{
			 new_bit=(int)(new_char & 0x80);
				if(new_bit==128)
					this_data.data[i*8+j]='1';
				else
					this_data.data[i*8+j]='0';
				new_char=new_char<<1;
			}
			if(feof(input_filed))
				break;

		}
		this_data.length=bits_read;


		string_copy_ss(&old_data,this_data);
		word_loop=0;
		while(old_data.length>0)
		{

			left_string(&temp_stringd , old_data , 16);
			left_shift_string(&old_data , 16);
			word_value=conv_bin_to_num(temp_stringd , 16);

			ram_array[local_address].word[word_loop]=word_value;
			word_loop++;
		}
		ram_array[local_address].length=bits_read;
		local_address++;
		num_reads++;

		string_copy_ss(&old_data , this_data);				// copy current_data to old_data
	}while((!feof(input_filed))&&(num_reads!=8192));
	return(num_reads);
}



/* function to read data from the ram_array at the given address */
void read_data_from_ram(int address_to_ram , string* data_from_ram)

{
	int word_loop;
	string temp_data_string;

	data_from_ram->length=0;
	for (word_loop=0; word_loop<4; word_loop++)
	{
		conv_num_to_bind(ram_array[address_to_ram].word[word_loop] , 16 , &temp_data_string);
		string_cat(data_from_ram , temp_data_string);
	}
	data_from_ram->length=ram_array[address_to_ram].length;
}



/* function to implement the tuple movement strategy */
/* this is currently a move to front strategy */

void move_to_front(int MAX_TABLE_ENTRIES)


{
	int tuple_loop;

	if((aoa_adaptationd > tuple_position || old_match_typed!=15) && (tuple_position<(MAX_TABLE_ENTRIES)))
	{
		tuple_position++;
	}
		/*aoa_adaptationd = 0 only in the first one*/
	if (((aoa_adaptationd==0 && match_typed!=15) || (old_match_typed!=15)) && (literal_positiond<(MAX_TABLE_ENTRIES)))
	{
		literal_positiond++;	/* if not a full hit, increment the literal position if we can, i.e we add the new tuple to the table */
	}

	if (old_match_typed==15)
	{
		for (tuple_loop=aoa_adaptationd; tuple_loop>0; tuple_loop--)
		{
			if (tuple_loop!=literal_positiond)
			{
				tuple[tuple_loop]=tuple[tuple_loop-1];		/* move tuple down one position */
			}
		}
	}
	else
	{
		for (tuple_loop=(literal_positiond-1); tuple_loop>0; tuple_loop--)
		{
			tuple[tuple_loop]=tuple[tuple_loop-1];			/* move tuple down one position */
		}
	}
	string_copy_ss(&tuple[0] , decoded_tuple);					/* enter decoded tuple at the front of table */

aoa_adaptationd=tuple_position;
old_match_typed=match_typed;

}

int misstypecode()	/*function to obtain a miss type code*/
{
	string miss_type_code;
	int m_type;
	int miss_length=0;
	int literal_chars=0;

	left_string(&miss_type_code , input_buffer , 1);			/* copy 2 match type code bits (match code is a max of 5 bits wide) */
	m_type=conv_bin_to_num(miss_type_code , 1);
	if(m_type==1)
	{
		miss_type=0;
		miss_length=1;
		literal_chars=0;
	}
	else
	{
		left_string(&miss_type_code , input_buffer , 2);			/* copy 3 match type code bits (match code is a max of 5 bits wide) */
		m_type=conv_bin_to_num(miss_type_code , 2);
		switch(m_type)
		{
			case 1:
				miss_type=4;
				miss_length=2;
				literal_chars=4;
				break;
			default :
					left_string(&miss_type_code , input_buffer , 3);	/* copy 4 match type code bits  */
					m_type=conv_bin_to_num(miss_type_code , 3);
					switch(m_type)
					{
						case 1:
							miss_type=1;
							miss_length=3;
							literal_chars=1;
							break;
						default :
							left_string(&miss_type_code , input_buffer , 4);	/* copy 5 match type code bits  */
							m_type=conv_bin_to_num(miss_type_code , 4);
							switch(m_type)
							{
								case 0:
									miss_type=3;
									miss_length=4;
									literal_chars=3;
									break;
								case 1:
									miss_type=2;
									miss_length=4;
									literal_chars=2;
									break;
								default:
									break;
							}
					}
		}

	}

	left_shift_string(&input_buffer , miss_length);			/* shift match type code bits out of the input buffer */
	return(literal_chars);
}


/* Function to get the next valid Huffman code */
int VerifyHuffmanCode()
{
	string match_typed_code;
	int m_type;
	int match_length=0;
	int literal_chars=0;
/*
	left_string(&match_typed_code , input_buffer , 1);			 copy 2 match type code bits (match code is a max of 5 bits wide) */
/*	m_type=conv_bin_to_num(match_typed_code , 1);
	if(m_type==1)
	{
		match_typed=15;
		match_length=1;
		literal_chars=0;
	}
	else
	{
		left_string(&match_typed_code , input_buffer , 3);			copy 3 match type code bits (match code is a max of 5 bits wide) */
/*		m_type=conv_bin_to_num(match_typed_code , 3);
		switch(m_type)
		{
			case 0:
				match_typed=7;
				match_length=3;
				literal_chars=1;
				break;
			case 2:
				match_typed=14;
				match_length=3;
				literal_chars=1;
				break;
			case 3:
				match_typed=0;
				match_length=3;
				literal_chars=0;
				break;
			default :
					left_string(&match_typed_code , input_buffer , 4);	copy 4 match type code bits  */
/*					m_type=conv_bin_to_num(match_typed_code , 4);
					switch(m_type)
					{
						case 2:
							match_typed=12;
							match_length=4;
							literal_chars=2;
							break;
						default :
							left_string(&match_typed_code , input_buffer , 6);	 copy 5 match type code bits  */
/*							m_type=conv_bin_to_num(match_typed_code , 6);
							switch(m_type)
							{
								case 15:
									match_typed=13;
									match_length=6;
									literal_chars=1;
									break;
								case 14:
									match_typed=11;
									match_length=6;
									literal_chars=1;
									break;
								case 12:
									match_typed=6;
									match_length=6;
									literal_chars=2;
									break;
								default:
									left_string(&match_typed_code , input_buffer , 7);	 copy 5 match type code bits  */
/*									m_type=conv_bin_to_num(match_typed_code , 7);
									switch(m_type)
									{
										case 27:
											match_typed=3;
											match_length=7;
											literal_chars=2;
											break;
										default:
											left_string(&match_typed_code , input_buffer , 8);	 copy 5 match type code bits  */
/*											m_type=conv_bin_to_num(match_typed_code , 8);
											switch(m_type)
											{
												case 52:
													match_typed=10;
													match_length=8;
													literal_chars=2;
													break;
												default:
													left_string(&match_typed_code , input_buffer , 9);	 copy 5 match type code bits  */
/*													m_type=conv_bin_to_num(match_typed_code , 9);
													switch(m_type)
													{
														case 106:
															match_typed=5;
															match_length=9;
															literal_chars=2;
															break;
														case 107:
															match_typed=9;
															match_length=9;
															literal_chars=2;
															break;
														default:
															printf("fatal error: match type not found\n");
															break;
													}

											}
									}
							}
					}
		}

	}*/


	left_string(&match_typed_code , input_buffer , 1);			/* copy 2 match type code bits (match code is a max of 5 bits wide) */
	m_type=conv_bin_to_num(match_typed_code , 1);
	if(m_type==1)
	{
		match_typed=15;
		match_length=1;
		literal_chars=0;
	}
	else
	{
		left_string(&match_typed_code , input_buffer , 3);			/* copy 3 match type code bits (match code is a max of 5 bits wide) */
		m_type=conv_bin_to_num(match_typed_code , 3);
		switch(m_type)
		{
			case 0:
				match_typed=7;
				match_length=3;
				literal_chars=1;
				break;
			case 2:
				match_typed=14;
				match_length=3;
				literal_chars=1;
				break;
			case 3:
				match_typed=0;
				match_length=3;
				literal_chars=0;
				break;
			default :
					left_string(&match_typed_code , input_buffer , 4);	/* copy 4 match type code bits  */
					m_type=conv_bin_to_num(match_typed_code , 4);
					switch(m_type)
					{
						case 2:
							match_typed=12;
							match_length=4;
							literal_chars=2;
							break;
						default :
							left_string(&match_typed_code , input_buffer , 6);	/* copy 5 match type code bits  */
							m_type=conv_bin_to_num(match_typed_code , 6);
							switch(m_type)
							{
								case 15:
									match_typed=13;
									match_length=6;
									literal_chars=1;
									break;
								case 14:
									match_typed=11;
									match_length=6;
									literal_chars=1;
									break;
								case 12:
									match_typed=3;
									match_length=6;
									literal_chars=2;
									break;
								case 13:
									match_typed=6;
									match_length=6;
									literal_chars=2;
									break;
								default:
									printf("fatal error: match type not found\n");
									break;
							}
					}
		}

	}

	left_shift_string(&input_buffer , match_length);			/* shift match type code bits out of the input buffer */
	return(literal_chars);
}




/* function to decode the current tuple from the input buffer */
void decode_tuple(int MAX_TABLE_ENTRIES)
{
	string phased_code_string;
	string literal_characters;
	int kd,threshold;		/* values for phased binary decoding */
	int location=0;
	int literal_chars;
	int this_character;
	int loop;
	int literal_char_position;
	string cam_data;
	string temp_stringd_aux;


	if (literal_positiond==0)					/* checkd if this is the first tuple to be decoded */
	{
		for (loop=0; loop<4; loop++)			/* if so, there are no code bits and the first tuple can be immediately decoded */
		{
			left_string(&temp_stringd , input_buffer , 8);			/* get any following literal characters */
			left_shift_string(&input_buffer , 8);					/* shift literal character bits out of the input buffer */
			this_character=conv_bin_to_num(temp_stringd , 8);		/* convert the bit stream to an 8 bit integer (i.e a character) */
			decoded_tuple.data[loop]=this_character;
		}
		decoded_tuple.length=4;
		tuple_position=0;											/* hit position is effectively zero */
		match_typed=0;												/* match type is 0 (total miss) */
	}
	else
	{
		if (input_buffer.data[0]==49)								/* checkd for a miss */ 
		{															/* this is the code for a miss */
			left_shift_string(&input_buffer , 1);/* remove the prefix bit from the input buffer */
			if (parser_active == 1)
			{
				literal_chars=misstypecode();
			}
			else
			{
				literal_chars=4;
			}
			loop=0;
			if (literal_chars == 4) /*four chars*/
			{
				while(input_buffer.length>0 && loop<4)
				{
					left_string(&temp_stringd , input_buffer , 8);		/* get any following literal characters */
					left_shift_string(&input_buffer , 8);				/* shift literal character bits out of the input buffer */
					this_character=conv_bin_to_num(temp_stringd , 8);	/* convert the bit stream to an 8 bit integer (i.e a character) */
					decoded_tuple.data[loop]=this_character;
					loop++;
				}
			}
			else /*some chars plus space*/
			{
				while(input_buffer.length>0 && loop<literal_chars)
				{
					left_string(&temp_stringd , input_buffer , 8);		/* get any following literal characters */
					left_shift_string(&input_buffer , 8);				/* shift literal character bits out of the input buffer */
					this_character=conv_bin_to_num(temp_stringd , 8);	/* convert the bit stream to an 8 bit integer (i.e a character) */
					decoded_tuple.data[loop]=this_character;
					loop++;
				}
				decoded_tuple.data[loop] = 32; /*add space*/
				loop++;
			}
			decoded_tuple.length=loop; /*loop generates different lengths*/
			tuple_position=literal_positiond;						/* hit position is the literal position (i.e a miss) */
			match_typed = 1;
			miss_type=0;											/* match type is 0 (total miss) */
		}
		else
		{															/* this is the code for a hit */
			left_shift_string(&input_buffer , 1);						/* remove the prefix bit from the input buffer */
			kd=(int)(0.99999+(log((double)literal_positiond))/log(2));	/* maximum number of bits in the phased code */
			threshold=2*((int)pow(2.0 , (double)kd)-literal_positiond);	/* calculate the threshold for kd and kd-1 bit codes */
			left_string(&phased_code_string , input_buffer , kd);	/* get bits from the input buffer that represent the phased code */
			location=conv_bin_to_num(phased_code_string , kd);		/* convert phased code to an integer */
			if (location<threshold)									/* see if code length is kd or kd-1 bits */
			{
				tuple_position=location/2;							/* code length is kd-1 */
				left_shift_string(&input_buffer , kd-1);				/* remove kd-1 phased code bits from the input buffer */
			}
			else
			{
				tuple_position=location-(threshold/2);				/* code length is kd */
				left_shift_string(&input_buffer , kd);				/* remove kd phased code bits from the input buffer */
			}
			literal_chars=VerifyHuffmanCode();						/* get a valid Huffman Code */
			literal_characters.length=0;
			if(match_typed == 0) /*detected run length*/
			{
				if(tuple_position == 0) /*run length code at zero*/
				{
					left_string(&temp_stringd , input_buffer , MAX_BITS_REPIT_ZERO);			/* get any following literal characters */
					left_shift_string(&input_buffer , MAX_BITS_REPIT_ZERO);
					repeticion_number = conv_bin_to_num(temp_stringd , MAX_BITS_REPIT_ZERO);
					run_length_detected = 1;
					string_copy_ss(&cam_data , tuple[0]);	/* get data from the 0 position of the cam array */
					decoded_tuple.length=0;
					for (loop=0; loop<cam_data.length; loop++)
					{
						decoded_tuple.data[loop]=cam_data.data[loop];
						decoded_tuple.length++;
					}
					match_typed = 15; /* move to front with perfect match type*/
				}
				else /*run length at other position*/
				{
					left_string(&temp_stringd , input_buffer , MAX_BITS_REPIT);			/* get any following literal characters */
					left_shift_string(&input_buffer , MAX_BITS_REPIT);
					repeticion_number = conv_bin_to_num(temp_stringd , MAX_BITS_REPIT);
					if(repeticion_number < 2) /*up tp 5*/
						repeticion_number = repeticion_number + 4;
					run_length_detected = 1;
					string_copy_ss(&cam_data , tuple[tuple_position]);	/* get data from the 0 position of the cam array */
					decoded_tuple.length=0;
					for (loop=0; loop<cam_data.length; loop++)
					{
						decoded_tuple.data[loop]=cam_data.data[loop];
						decoded_tuple.length++;
					}
					match_typed = 15; /* move to front with perfect match type*/
				}
			}
			else
			{
				run_length_detected = 0;
			/*	for (loop=0; loop<literal_chars; loop++)
				{

					if(this_character == PARSER)
						break;

				}*/
				string_copy_ss(&cam_data , tuple[tuple_position]);				/* get data from the match position of the cam array */
				conv_num_to_bind(match_typed , 4 , &temp_stringd);
				literal_char_position=0;
				decoded_tuple.length=0;
				for (loop=0; loop<=3; loop++)
				{
					if (temp_stringd.data[loop]==48/*&&literal_characters.length>0*/)
					{
						if(input_buffer.length>0)
						literal_characters.length++;
						else
							break;
						left_string(&temp_stringd_aux , input_buffer , 8);			/* get any following literal characters */
						left_shift_string(&input_buffer , 8);					/* shift literal character bits out of the input buffer */
						this_character=conv_bin_to_num(temp_stringd_aux , 8);		/* convert the bit stream to an 8 bit integer (i.e a character) */
						/*literal_characters.data[loop]=this_character;*/
						decoded_tuple.data[loop]=this_character;
						literal_char_position++;
						literal_characters.length--;
						decoded_tuple.length++;
						/*if(decoded_tuple.data[loop] == PARSER)
							break; tuple reconstructed*/
					}
					if(temp_stringd.data[loop]==49 && cam_data.length > loop)
					{
						decoded_tuple.data[loop]=cam_data.data[loop];
						decoded_tuple.length++;
						/*if(decoded_tuple.data[loop] == PARSER && match_typed!=15)
							break;*/
					}
				}
			}
		}
	}
}







/* function to update the bit count to the output file */

void update_bit_count(int found_position)

{
	if (found_position==literal_positiond)
	{
		missesd++;
		if (literal_positiond>0)
		{
			output_bitsd++;
			blockd_output_bitsdd++;
		}
		output_bitsd=output_bitsd+8*tuple[literal_positiond].length;
		blockd_output_bitsdd=blockd_output_bitsdd+8*tuple[literal_positiond].length;
	}
	else
	{
		hitsd++;
		if (found_position<twokdminusrowd)
		{
			output_bitsd=output_bitsd+kd;				/* add in bit length of code sent out */
			blockd_output_bitsdd=blockd_output_bitsdd+kd;	/* add in bit length of code sent out to blockd total */
		}
		else
		{
			output_bitsd=output_bitsd+kd+1;
			blockd_output_bitsdd=blockd_output_bitsdd+kd+1;
		}
		output_bitsd=output_bitsd+match_bits_to_outputd;
		blockd_output_bitsdd=blockd_output_bitsdd+match_bits_to_outputd;
		if (match_typed!=0)
		{
			output_bitsd=output_bitsd+8*literal_characters_requiredd;
			blockd_output_bitsdd=blockd_output_bitsdd+8*literal_characters_requiredd;
		}
	}

}

void ch_bytobid(string buffer,int fin)
{
	int counter=0,l=0,length_for=0,last,i;
	unsigned char new_byte=0x00;
/*	if(fin==1)*/
		length_for=buffer.length;
/*	else
		length_for=32;  */            /* Each time writes a tuple (32 bits ) */
	last=length_for;
	for(l=0;l<length_for;l++)
	{
		if (buffer.data[l] =='1')
		{
			new_byte=(new_byte | 0x1);
			counter++;
		}
		else
			counter++;
		if(counter==8)
		{
			//printf("%d\n",output_file_desc);
			//if ((int)output_file_desc != 135237800)
			//	printf("hello\n");
			fputc(new_byte,output_file_desc);
			counter=0;
			last=last-8;
		}
		if((fin==1)&&(l==length_for-1))
		{
			for(i=0;i<8-length_for-1;i++)
			{
				new_byte=(new_byte | 0x1);
				new_byte=new_byte<<1;
			}
			new_byte=(new_byte | 0x1);
			//fputc(new_byte,output_file_desc);
		}
		new_byte=new_byte<<1;
	}
}



/* function to write a tuple */
void write_vector()
{
	string u_dataout;
	int byte_number;
	string temp_stringd;

	u_dataout.length=0;

	for (byte_number=0; byte_number<decoded_tuple.length; byte_number++)
	{
		conv_num_to_bind(decoded_tuple.data[byte_number] , 8 , &temp_stringd);

		string_cat(&u_dataout , temp_stringd);
	}
	ch_bytobid(u_dataout, 0);
}



///////////////////////////
/* start of main program */
///////////////////////////

int main(int argc, char *argv[])
{

	int terminate = 0;
	int dictionary_size;
	int block_size;
	int parser;
	 clock_t start, finish;
   long double  duration;
	int running,max_tuples=0,flag=0;
	int run_length_loop; /* to loop when dealing with run lengths*/
	int previous_tuple_position;
	int bytes_write; /*to reconstruct a number of bytes*/
	int blockd = 1;
	int tuples_read_local = 0;
	zero.data[0]=48;
	zero.length=1;
	//char first_string[1000];

	long double total_bytes_writed = 0.0;  //performance measurement
	long double total_tuples_readd = 0.0;


	printf("X-MatchPROvw 5.2 decompressor\n");

	if(argc<6)
	{

		printf("Incorrect number of parameters\n");
		printf("xmw52d <dic size> <block size> <parser> <in file> <out file>\n");
		printf("Dictionary sizes can be set to any value up 4096\n");
		printf("Parser can have the value 0 (inactive), value 1 (active) or value 2 (active dynamically => recomended)\n");

		printf("X-MatchPROvw decompresses blocks of <block_size> bytes at a time only one file at a time\n");
		printf("The parameters <dic size> <block size> <parser> must be the same as in compression\n");
		printf("Please report any bugs at J.L.Nunez-Yanez@lboro.ac.uk\n");
		exit(1);
	}



	if (block_size==0)
	{
		printf("error - can't run in unblockded mode!\n");
		exit(1);
	}
	if(block_size <4)
	{
			printf("error - block size minimum is 4\n");
			exit(1);
	}
	/*if(block_size > 16384)
	{
		printf("error - maximum blockd size is 16384");
		exit(1);
	}*/
	dictionary_size = atoi(argv[1]);
	block_size = atoi(argv[2]);
	parser = atoi(argv[3]);

	switch(dictionary_size)
	{
	case 16:
	case 32:
	case 64:
	case 128:
	case 256:
	case 512:
	case 1024:
	case 2048:
	case 3072:
	case 4096:
		{
			printf("Dictionary Size: %d\n",dictionary_size);
			printf("Block Size: %d\n",block_size);

	    	break;
		}
	default:
		{
			printf("Ilegal dictionary size - PROGRAM TERMINATED\n");
			exit(1);
		}
	}

    if (parser == 1 || parser == 2)
		parser_active = 1;
	else
		parser_active = 0;

	strcpy(name_of_input_filed , argv[4]);			/* get name of input file from command line */
	strcpy(name_of_output_filed, argv[5]);


	printf("Input  file: %s\n",name_of_input_filed);
	printf("Output  file: %s\n\n", name_of_output_filed);


	if(!(input_filed=fopen(name_of_input_filed, "rb")))		// open compression vector file for reading
	{
		printf("Fatal error: fail to open input file for reading\n");
		terminate = 1;
	}

	if(!(output_file_desc=fopen(name_of_output_filed, "wb")))		// open compression vector file for writting
	{
		printf("Fatal error: fail to open output file for writting\n");
		terminate = 1;
	}


	if (terminate == 0)
	{

		input_buffer.length=0;							/* clear input buffer */
		literal_positiond=1; /*0 is full of zeros rest invalid RL as a match type*/
		tuples_read=0;
									/* zero arrays */
		characters_readd=0;								/* clear characters_readd */
		running=1;
		zero_arraysd(dictionary_size); /**/
		aoa_adaptationd=0;
		old_match_typed=15;
		bytes_write =0;
		start = clock();
		do
		{
			address=0;
			max_tuples=read_data_into_ram();			/* read data from compressed vector file into ram_array */
			if (input_buffer.length<35)
			{
				read_data_from_ram(address , &ram_data);	/* read data from ram location 0 */
				string_cat(&input_buffer , ram_data);		/* and place into input_buffer */
				address++;									/* move to next address */
			}
			do
			{
				repeticion_number = 1; /*execute loop only once*/
				decode_tuple(dictionary_size);							/* decode the current tuple - provides tuple_position , match_typed and decoded_tuple */
				if (input_buffer.length<35)
				{
					read_data_from_ram(address , &ram_data);	/* read data from RAM if we have less than 33 bits in the input buffer */
					string_cat(&input_buffer , ram_data);
					underflow=0;
					address++;
				}
				else
					underflow=1;

				/*if(repeticion_number == 255)
				{
						printf("hello");
				}*/

				for(run_length_loop=repeticion_number;run_length_loop>0;run_length_loop--)
				{
					write_vector();	 /* write test vector */
					bytes_write = bytes_write + decoded_tuple.length;
					total_bytes_writed = total_bytes_writed + decoded_tuple.length;
					previous_tuple_position = tuple_position; /*saved found position*/
					if (decoded_tuple.length!=1)
					{
						move_to_front(dictionary_size); /*move to front no plus one*/								/* re-order the cam array */
					}
				/*	else
					{
						printf("hello");
					}*/
					string_copy_ss(&decoded_tuple , tuple[previous_tuple_position]);	/* get data from the 0 position of the cam array */
					tuple_position = previous_tuple_position;
					tuples_read++;
					tuples_read_local++;
					total_tuples_readd ++;
				//	printf("%d\n",tuples_read_local);
				/*	if(tuples_read_local == 1000 && blockd == 5)
					{
						printf("hello");
					}*/
				}
				decoded_tuple.length=0;
				//if (tuples_read_local == 26634)
				//	printf("hello\n");
				//if (address == max_tuples-1)
				//	printf("hello\n");
				if(bytes_write>=block_size)
				{
					literal_positiond=1; /*zero full of zeros*/
					zero_arraysd(dictionary_size);
					aoa_adaptationd=0; /*reinitialize*/
					old_match_typed=15;
					bytes_write = 0;
					tuples_read_local = 0;
					blockd ++;
					if(tuples_read>=8192)
						tuples_read=0;
				//	if(blockd >= 4797)
				//	{
				//		printf("hello");
				//	}
				}
			}while((address<max_tuples));

		}while(!(feof(input_filed)));
	finish = clock();

	if(input_buffer.length>0)
	{
		blockd ++;

	do
	{

		flag=0;
	//	if(input_buffer.length>1000)
	//	{
	//		fclose(input_filed);								// close input file
	//		fclose(output_file_desc);
	//		break;
	//	}
	//	for(i=0;i<input_buffer.length;i++)
	//	{
	//		if(input_buffer.data[i]=='0')
	//			flag=1;
	//	}
	//	if(flag==0)
	//	{
	//		fclose(input_filed);								// close input file
	//		fclose(output_file_desc);
	//		break;
	//	}
		repeticion_number=1;
		decode_tuple(dictionary_size);
		for(run_length_loop=repeticion_number;run_length_loop>0;run_length_loop--)
		{
			write_vector();
			bytes_write = bytes_write + decoded_tuple.length;
			total_bytes_writed = total_bytes_writed + decoded_tuple.length;
			total_tuples_readd ++;
			previous_tuple_position = tuple_position; /*saved found position*/
			if (decoded_tuple.length!=1)
			{
				move_to_front(dictionary_size); /*move to front no plus one*/								/* re-order the cam array */
			}
			string_copy_ss(&decoded_tuple , tuple[previous_tuple_position]);	/* get data from the 0 position of the cam array */
			tuple_position = previous_tuple_position;
		}
		if(bytes_write>=block_size)
		{
			literal_positiond=1; /*zero full of zeros*/
			zero_arraysd(dictionary_size);
			aoa_adaptationd=0; /*reinitialize*/
			old_match_typed=15;
			bytes_write = 0;
			tuples_read_local = 0;
			blockd ++;
		}
	}while(input_buffer.length>0);

	}

	fclose(input_filed);										// close input file
	//fclose(output_file_desc);								// close decompressed file

	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	printf("It took: %f seconds to process the file(s)\n",(float)duration);
	printf("Decompression done!\n\n\n");

	//delete aux_string;


	}
	exit(0);
}

